# MIW Advanced Programming 
**assignment 5 Trains and Wagons**

This is a Maven project.

Read Assignment.md in folder 'assignment'
