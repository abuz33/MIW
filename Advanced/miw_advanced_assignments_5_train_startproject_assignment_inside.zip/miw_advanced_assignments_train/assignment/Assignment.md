# MIW Advanced Programming 
**assignment 5 Trains and Wagons**
**Linked list structure**

## Introduction

The start project contains a Train program. 
Trains are chains of Wagons which are connected to eachother. A Shunter is an object that can manipulate trains and wagons.

The Wagon class is finished, so no code needs to change. Read the javadoc of the Wagon class and view the tests to find out 
the requirements of this class.

a train interface is described in Interface ITrain. See the javadoc & tests for the requirements.
A skeleton implementation for this interface is given in the Train class. 
The Shunter class is partly implemented. See the javadoc & tests for the requirements.

Write extra tests when you think you need them.

## Questions

a. implement the methods in class Train. Run the tests to feel confident about your implementation. Start with simple 
methods first. Add default methods.

b. Add a test to the TrainTest class which uses a Comparator to sort Trains on the sum of the Wagon numbers.

c. implement methods in class Shunter. Run the tests to feel confident about your implementation. Start with simple
methods first. Add default methods.

d. Make a test to add a natural ordering to class Train. Make sure trains are ordered by their length. 
Add/override all necessary methods.

e. What is the algoritmic order of the following methods?
* addWagon
* getLength
* getPosition
* getWagonNumber
* removeWagon
* returnTrainInReverseOrder
* returnTrainInStandardOrder

### Questions below are optional

f. Extract the interface ITrain from class Train. This interface should contain the methods:
* addWagon
* getLength
* getPosition
* getWagonNumber
* removeWagon
* returnTrainInReverseOrder
* returnTrainInStandardOrder

g. Create a new implementation of the ITrain interface called FastTrain which has an O(1) implementation of
* addWagon
* getLength
* getPosition
* getWagonNumber
* removeWagon

Check this by creating a test class FastTrainTest which shows all behaviour still works. Do this by
copying all tests from TrainTest into FastTrainTest, and by replacing all 'new Train(' with 'new FastTrain('

h. Add a test class which measures and shows the performance difference of the Train and FastTrain implementations for the 
above mentioned methods.
