package model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class WagonTest {
    private static final int VALID_WAGON_NUMBER = 5;
    private static final int NEGATIVE_WAGON_NUMBER = 5;

    /**
     * @verifies create a wagon with a valid wagonnumber
     * @see Wagon#Wagon(int)
     */
    @Test
    public void Wagon_shouldCreateAWagonWithAValidWagonnumber() throws Exception {
        // Arrange
        // Act
        Wagon sut = new Wagon(VALID_WAGON_NUMBER);
        // Assert
       assertEquals(VALID_WAGON_NUMBER,sut.getNumber());
    }

    /**
     * @verifies throw illegalargument when number is negative
     * @see Wagon#Wagon(int)
     */
    @Test
    public void Wagon_shouldThrowIllegalargumentWhenNumberIsNegative() throws Exception {
        assertThrows(IllegalArgumentException.class,()->{new Wagon(NEGATIVE_WAGON_NUMBER);});
    }
}
