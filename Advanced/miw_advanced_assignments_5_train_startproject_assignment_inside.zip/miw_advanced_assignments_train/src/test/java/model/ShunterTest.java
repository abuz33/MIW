package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ShunterTest {
    private static final int WAGON_NOT_FOUND_WAGONNUMBER = -1;
    private static final int WAGON_NOT_FOUND_POSITION = 0;

    Train train1 = new Train();
    Train train2 = new Train();
    
    @BeforeEach
    public void setUp(){
        train1.addWagon(1, 1);
        train1.addWagon(2, 2);
        train1.addWagon(12, 3);
        train1.addWagon(10, 4);
        //
        train2.addWagon( 101, 1 );
        train2.addWagon( 102, 2 );
        train2.addWagon( 103, 3 );
        train2.addWagon( 104, 4 );

    }
    
    
    /**
     * @verifies move wagon with given wagonnumber from originator train to destination train when train and wagon exist
     * @see Shunter#moveWagonBetweenTrains(Train, Train, int)
     */
    @Test
    public void moveWagonBetweenTrains_shouldMoveWagonWithGivenWagonnumberFromOriginatorTrainToDestinationTrainWhenTrainAndWagonExist() throws Exception {
        // Arrange
        Shunter sut = new Shunter();
        int wagonToMove = 2;
        // Act
        sut.moveWagonBetweenTrains(train1,train2,wagonToMove);
        // Assert
        assertEquals(3,train1.getLength());
        assertEquals(WAGON_NOT_FOUND_POSITION,train1.getPosition(wagonToMove));
        assertEquals(5,train2.getLength());
        assertEquals(5,train2.getPosition(wagonToMove));
    }

    /**
     * @verifies do nothing when train is null
     * @see Shunter#moveWagonBetweenTrains(Train, Train, int)
     */
    @Test
    public void moveWagonBetweenTrains_shouldDoNothingWhenTrainIsNull() throws Exception {
        // Arrange
        Shunter sut = new Shunter();
        int wagonToMove = 2;
        // Act
        sut.moveWagonBetweenTrains(null,train2,wagonToMove);
        // Assert
        assertEquals(4,train1.getLength());
        assertEquals(4,train2.getLength());
        // Act
        sut.moveWagonBetweenTrains(train1,null,wagonToMove);
        // Assert
        assertEquals(4,train1.getLength());
        assertEquals(4,train2.getLength());

    }

    /**
     * @verifies do nothing when wagon with given number cannot be found
     * @see Shunter#moveWagonBetweenTrains(Train, Train, int)
     */
    @Test
    public void moveWagonBetweenTrains_shouldDoNothingWhenWagonWithGivenNumberCannotBeFound() throws Exception {
        // Arrange
        Shunter sut = new Shunter();
        int wagonToMove = 9999;
        // Act
        sut.moveWagonBetweenTrains(train1,train2,wagonToMove);
        // Assert
        assertEquals(4,train1.getLength());
        assertEquals(4,train2.getLength());
    }

    /**
     * @verifies add wagon to a given train, behind a given wagon when train and wagon exist
     * @see Shunter#addNewWagonBehindWagon(Train, int, int)
     */
    @Test
    public void addNewWagonBehindWagon_shouldAddWagonToAGivenTrainBehindAGivenWagonWhenTrainAndWagonExist() throws Exception {
        // Arrange
        Shunter sut = new Shunter();
        int wagonToAdd = 22;
        int wagonToAdd2 = 222;

        // Act
        sut.addNewWagonBehindWagon(train2,wagonToAdd,101);
        // Assert
        assertEquals(5,train2.getLength());
        assertEquals(2,train2.getPosition(wagonToAdd));
        // Act
        sut.addNewWagonBehindWagon(train2,wagonToAdd2,104);
        // Assert
        assertEquals(6,train2.getLength());
        assertEquals(6,train2.getPosition(wagonToAdd2));
    }

    /**
     * @verifies do nothing when train is null
     * @see Shunter#addNewWagonBehindWagon(Train, int, int)
     */
    @Test
    public void addNewWagonBehindWagon_shouldDoNothingWhenTrainIsNull() throws Exception {
        // Arrange
        Shunter sut = new Shunter();
        int wagonToAdd = 22;
        // Act
        sut.addNewWagonBehindWagon(null,wagonToAdd,101);
        // Assert
        assertEquals(4,train1.getLength());
        assertEquals(4,train2.getLength());
    }

    /**
     * @verifies do nothing when wagon to add behind is not found.
     * @see Shunter#addNewWagonBehindWagon(Train, int, int)
     */
    @Test
    public void addNewWagonBehindWagon_shouldDoNothingWhenWagonToAddBehindIsNotFound() throws Exception {
        // Arrange
        Shunter sut = new Shunter();
        int wagonToAdd = 22;
        // Act
        sut.addNewWagonBehindWagon(null,wagonToAdd,222);
        // Assert
        assertEquals(4,train1.getLength());
        assertEquals(4,train2.getLength());
    }

    /**
     * @verifies add wagon to a given train, before a given wagon when train and wagon exist
     * @see Shunter#addNewWagonBeforeWagon(Train, int, int)
     */
    @Test
    public void addNewWagonBeforeWagon_shouldAddWagonToAGivenTrainBeforeAGivenWagonWhenTrainAndWagonExist() throws Exception {
        // Arrange
        Shunter sut = new Shunter();
        int wagonToAdd = 22;
        int wagonToAdd2 = 222;

        // Act
        sut.addNewWagonBeforeWagon(train2,wagonToAdd,101);
        // Assert
        assertEquals(5,train2.getLength());
        assertEquals(1,train2.getPosition(wagonToAdd));
        // Act
        sut.addNewWagonBeforeWagon(train2,wagonToAdd2,104);
        // Assert
        assertEquals(6,train2.getLength());
        assertEquals(5,train2.getPosition(wagonToAdd2));

    }

    /**
     * @verifies do nothing when train is null
     * @see Shunter#addNewWagonBeforeWagon(Train, int, int)
     */
    @Test
    public void addNewWagonBeforeWagon_shouldDoNothingWhenTrainIsNull() throws Exception {
        // Arrange
        Shunter sut = new Shunter();
        int wagonToAdd = 22;
        // Act
        sut.addNewWagonBeforeWagon(null,wagonToAdd,101);
        // Assert
        assertEquals(4,train1.getLength());
        assertEquals(4,train2.getLength());
    }

    /**
     * @verifies do nothing when wagon to add before is not found.
     * @see Shunter#addNewWagonBeforeWagon(Train, int, int)
     */
    @Test
    public void addNewWagonBeforeWagon_shouldDoNothingWhenWagonToAddBeforeIsNotFound() throws Exception {
        // Arrange
        Shunter sut = new Shunter();
        int wagonToAdd = 22;
        // Act
        sut.addNewWagonBeforeWagon(null,wagonToAdd,222);
        // Assert
        assertEquals(4,train1.getLength());
        assertEquals(4,train2.getLength());
    }
}
