package model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TrainTest {
    private static final int VALID_WAGON_NUMBER = 5;
    private static final int VALID_POSITION = 2;
    private static final int INVALID_POSITION = -2;
    private static final int WAGON_NOT_FOUND_WAGONNUMBER = -1;
    private static final int WAGON_NOT_FOUND_POSITION = 0;

    /**
     * @verifies create train with length 0
     * @see Train#Train()
     */
    @Test
    public void Train_shouldCreateTrainWithLength0() throws Exception {
        // Arrange
        // Act
        Train sut = new Train();
        // Assert
        assertEquals(0, sut.getLength());

    }

    /**
     * @verifies return -1 when no wagon is present in the train
     * @see Train#getWagonNumber(int)
     */
    @Test
    public void getWagonNumber_shouldReturnMinus1WhenNoWagonIsPresentInTheTrain() throws Exception {
        // Arrange
        // Act
        Train sut = new Train();
        // Assert
        assertEquals(WAGON_NOT_FOUND_WAGONNUMBER, sut.getWagonNumber(VALID_WAGON_NUMBER));
    }

    /**
     * @verifies return the position of the wagon when it is present
     * @see Train#getWagonNumber(int)
     */
    @Test
    public void getWagonNumber_shouldReturnThePositionOfTheWagonWhenItIsPresent() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        // Act
        // Assert
        assertEquals(12, sut.getWagonNumber(VALID_POSITION));
    }

    /**
     * @verifies return minus1 when position is smaller than 1
     * @see Train#getWagonNumber(int)
     */
    @Test
    public void getWagonNumber_shouldReturnMinus1WhenPositionIsSmallerThan1() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        // Act
        // Assert
        assertEquals(WAGON_NOT_FOUND_WAGONNUMBER, sut.getWagonNumber(INVALID_POSITION));
    }


    /**
     * @verifies return -1 when no wagon is present at the position
     * @see Train#getWagonNumber(int)
     */
    @Test
    public void getWagonNumber_shouldReturnMinus1WhenNoWagonIsPresentAtThePosition() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        // Act
        // Assert
        assertEquals(WAGON_NOT_FOUND_WAGONNUMBER, sut.getWagonNumber(sut.getLength() + VALID_POSITION));
    }



    /**
     * @verifies return the position when wagon is present
     * @see Train#getPosition(int)
     */
    @Test
    public void getPosition_shouldReturnThePositionWhenWagonIsPresent() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        // Act
        // Assert
        assertEquals(2, sut.getPosition(12));
        assertEquals(3, sut.getPosition(9));
        assertEquals(1, sut.getPosition(23));
    }


    /**
     * @verifies return 0 when the wagon is not present
     * @see Train#getPosition(int)
     */
    @Test
    public void getPosition_shouldReturn0WhenTheWagonIsNotPresent() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        // Act
        // Assert
        assertEquals(WAGON_NOT_FOUND_POSITION, sut.getPosition(142));
    }

    /**
     * @verifies return 0 when the train has no wagons
     * @see Train#getPosition(int)
     */
    @Test
    public void getPosition_shouldReturn0WhenTheTrainHasNoWagons() throws Exception {
        // Arrange
        Train sut = new Train();
        // Act
        // Assert
        assertEquals(WAGON_NOT_FOUND_POSITION, sut.getPosition(VALID_POSITION));
    }

    /**
     * @verifies add a Wagon to the train on a given position smaller than or equal to the size of the train
     * @see Train#addWagon(int, int)
     */
    @Test
    public void addWagon_shouldAddAWagonToTheTrainOnAGivenPositionSmallerThanOrEqualToTheSizeOfTheTrain() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        // Act
        sut.addWagon(15, 2);
        sut.addWagon(102, 1);
        sut.addWagon(103, 4);
        // Assert
        assertEquals(3, sut.getPosition(15));
        assertEquals(1, sut.getPosition(102));
        assertEquals(4, sut.getPosition(103));
    }

    /**
     * @verifies add a wagon to the end of the train when the position is larger than the size of the train
     * @see Train#addWagon(int, int)
     */
    @Test
    public void addWagon_shouldAddAWagonToTheEndOfTheTrainWhenThePositionIsLargerThanTheSizeOfTheTrain() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        // Act
        sut.addWagon(14, 13);
        // Assert
        assertEquals(4, sut.getLength());
        assertEquals(4, sut.getPosition(14));
    }

    /**
     * @verifies remove a wagon when the wagon is present
     * @see Train#removeWagon(int)
     */
    @Test
    public void removeWagon_shouldRemoveAWagonWhenTheWagonIsPresent() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        sut.addWagon(14, 13);
        // Act
        sut.removeWagon(2);
        // Assert
        assertEquals(3, sut.getLength());
        assertEquals(2, sut.getPosition(9));
    }

    /**
     * @verifies do nothing when the wagon is not found
     * @see Train#removeWagon(int)
     */
    @Test
    public void removeWagon_shouldDoNothingWhenTheWagonIsNotFound() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        sut.addWagon(14, 13);
        // Act
        sut.removeWagon(8);
        // Assert
        assertEquals(4, sut.getLength());
        assertEquals(4, sut.getPosition(13));
    }

    /**
     * @verifies return empty string when train has no wagons
     * @see Train#returnTrainInStandardOrder()
     */
    @Test
    public void returnTrainInStandardOrder_shouldReturnEmptyStringWhenTrainHasNoWagons() throws Exception {
        // Arrange
        Train sut = new Train();
        // Act
        String trainInOrder = sut.returnTrainInStandardOrder();
        // Assert
        assertEquals("", trainInOrder);
    }

    /**
     * @verifies return wagons in increasing position
     * @see Train#returnTrainInStandardOrder()
     */
    @Test
    public void returnTrainInStandardOrder_shouldReturnWagonsInIncreasingPosition() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        sut.addWagon(14, 13);
        // Act
        String trainInOrder = sut.returnTrainInStandardOrder();
        // Assert
        assertEquals("23,12,9,14", trainInOrder);
    }

    /**
     * @verifies return empty string when train has no wagons
     * @see Train#returnTrainInReverseOrder()
     */
    @Test
    public void returnTrainInReverseOrder_shouldReturnEmptyStringWhenTrainHasNoWagons() throws Exception {
        // Arrange
        Train sut = new Train();
        // Act
        String trainInOrder = sut.returnTrainInReverseOrder();
        // Assert
        assertEquals("", trainInOrder);
    }

    /**
     * @verifies return wagons in increasing position
     * @see Train#returnTrainInReverseOrder()
     */
    @Test
    public void returnTrainInReverseOrder_shouldReturnWagonsInIncreasingPosition() throws Exception {
        // Arrange
        Train sut = new Train();
        sut.addWagon(23, 1);
        sut.addWagon(12, 2);
        sut.addWagon(9, 3);
        sut.addWagon(14, 13);
        // Act
        String trainInOrder = sut.returnTrainInReverseOrder();
        // Assert
        assertEquals("14,9,12,23", trainInOrder);
    }

    /**
     * @verifies compare trains on their length
     * @see Train#Train()
     */
    @Test
    public void Train_shouldCompareTrainsOnTheirLength() throws Exception {
        // Arrange
        Train t1 = new Train();
        t1.addWagon(400, 1);
        t1.addWagon(300, 2);
        t1.addWagon(100, 3);

        Train t2 = new Train();
        t2.addWagon(40, 1);
        t2.addWagon(30, 2);
        t2.addWagon(10, 3);
        t2.addWagon(20, 4);

        Train t3 = new Train();
        t3.addWagon(4, 1);
        t3.addWagon(3, 2);

        Train[] trainArray = new Train[3];
        trainArray[0] = t1;
        trainArray[1] = t2;
        trainArray[2] = t3;

        Train[] expected = new Train[3];
        expected[0] = t3;
        expected[1] = t1;
        expected[2] = t2;
        // Act
        Arrays.sort(trainArray);
        // Assert
        assertArrayEquals(trainArray, expected);
    }

    /**
     * @verifies compare trains on the sum of the wagon numbers.
     * @see Train#Train()
     */
    @Test
    public void Train_shouldCompareTrainsOnTheSumOfTheWagonNumbers() throws Exception {
        //TODO auto-generated
        Assertions.fail("Not yet implemented");
    }



}
