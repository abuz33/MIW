package model;

/**
 * Wagon class
 *
 * Each wagon is uniquely identified by it's number
 * it also has a link to the previous and next Wagon.
 *
 * @author michel
 * @author erik translation to English/conversion to mvn/assignment description in markdown/added tests
 *
 */
public class Wagon {
    private int number;

    private Wagon next = null;
    private Wagon previous = null;

    /**
     *
     * @param number number of the wagon. must be a non-negative number.
     * @throws IllegalArgumentException when number is negative
     * @should create a wagon with a valid wagonnumber
     * @should throw illegalargument when number is negative
     */
    public Wagon(int number) throws IllegalArgumentException{
        if(number < 0){
            throw new IllegalArgumentException("number cannot be negative");
        }
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    public Wagon getNext() {
        return next;
    }

    public void setNext(Wagon next) {
        this.next = next;
    }

    public Wagon getPrevious() {
        return previous;
    }

    public void setPrevious(Wagon previous) {
        this.previous = previous;
    }
}
