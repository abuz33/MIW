package model;


/**
 * Train class.
 * A train is a collection of Wagons
 * 
 * Wagons in a train each have a position number in the train. The first wagon has position 1.
 */
public class Train  {
    private int length;
    private Wagon firstWagon;


    /**
     * @should create train with length 0
     * @should compare trains on their length
     * @should compare trains on the sum of the wagon numbers.
     */
    public Train() {
        this.length = 0;
        firstWagon = null;
    }

    public int getLength() {
        return length;
    }

    /**
     * Returns the number of the Wagon in this train
     *
     * @param position position of the wagon in this train
     * @return the number of the Wagon. or -1 when no Wagon exists on this number;
     * @should return minus1 when no wagon is present in the train
     * @should return the position of the wagon when it is present
     * @should return minus1 when no wagon is present at the position
     * @should return minus1 when position is smaller than 1
     */
    public int getWagonNumber(int position) {
        // TODO
        return 0;
    }

    /**
     * returns the postion of wagon
     *
     * @param wagonNumber number of the wagon to search for
     * @return position of the given wagon. 0 if the wagon is not present.
     * @should return the position when wagon is present
     * @should return 0 when the wagon is not present
     * @should return 0 when the train has no wagons
     */
    public int getPosition(int wagonNumber) {
        return 0;
        // TODO
    }

    /**
     * @param wagonNumber wagonnumber of the wagon to add
     * @param position    position in the train to add the wagon to. if position is larger than the
     *                    current size of the train, the wagon is added to the end of the train.
     * @should add a Wagon to the train on a given position smaller than or equal to the size of the train
     * @should add a wagon to the end of the train when the position is larger than the size of the train
     */
    public void addWagon(int wagonNumber, int position) {
        // TODO
    }

    /**
     * removes a wagon
     *
     * @param position
     * @should remove a wagon when the wagon is present
     * @should do nothing when the wagon is not found
     */
    public void removeWagon(int position) {
        // TODO
    }

    /**
     * Helper method
     *
     * @param w
     * @return
     */
    private Wagon getNextWagon(Wagon w) {
        return w.getNext();
    }

    /**
     * Helper method
     *
     * @param w
     * @return
     */
    private Wagon getPreviousWagon(Wagon w) {
        return w.getPrevious();
    }


    /**
     * @return all wagons in increasing position
     * @should return empty string when train has no wagons
     * @should return wagons in increasing position
     */

    public String returnTrainInStandardOrder() {
        StringBuffer sb = new StringBuffer();
        sb.append("Train{ length=" + length + " }");
        Wagon w = firstWagon;
        while (w != null ) {
            sb.append( " " + w.getNumber() );
            w = getNextWagon(w);
        }

        return sb.toString();
    }

    /**
     * @return all wagons of the train in decreasing position
     * @should return empty string when train has no wagons
     * @should return wagons in increasing position
     */
    public String returnTrainInReverseOrder() {
        StringBuffer sb = new StringBuffer();
        sb.append("Train{ length=" + length + " }");
        Wagon w = firstWagon;
        // Loop naar de laatste wagon
        while (w != null && getNextWagon(w) != null ) {
            w = getNextWagon(w);
        }

        while (w != null ) {
            sb.append( " " + w.getNumber() );
            w = getPreviousWagon(w);
        }

        return sb.toString();
    }

}