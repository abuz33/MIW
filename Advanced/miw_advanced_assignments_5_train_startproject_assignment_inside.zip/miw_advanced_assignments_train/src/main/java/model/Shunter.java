package model;

/**
 * Shunter class.
 * Has methods to manipulate trains.
 *
 * @author michel
 * @author erik adaptation and translation to English
 */
public class Shunter {


    public Shunter() {
    }

    /**
     * @param originatorTrain  train to remove given Wagon from
     * @param destinationTrain train where wagon is added at the end of the train.
     * @param wagonNumber
     * @should move wagon with given wagonnumber from originator train to destination train when train and wagon exist
     * @should do nothing when train is null
     * @should do nothing when wagon with given number cannot be found
     */
    public void moveWagonBetweenTrains(Train originatorTrain, Train destinationTrain, int wagonNumber) {
        // TODO
    }

    /**
     * @param train
     * @param newWagonNumber
     * @param wagonNumberToAddBehind
     * @should add wagon to a given train, behind a given wagon when train and wagon exist
     * @should do nothing when train is null
     * @should do nothing when wagon to add behind is not found.
     */
    public void addNewWagonBehindWagon(Train train, int newWagonNumber, int wagonNumberToAddBehind) {
        // TODO
    }


    /**
     * @param train
     * @param newWagonNumber
     * @param wagonNumberToAddBefore
     * @should add wagon to a given train, before a given wagon when train and wagon exist
     * @should do nothing when train is null
     * @should do nothing when wagon to add before is not found.
     */
    public void addNewWagonBeforeWagon(Train train, int newWagonNumber, int wagonNumberToAddBefore) {
        // TODO
    }
}
