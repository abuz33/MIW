package chapter1;

public class ComputeExpression { 
  public static void main(String[] args) { 
    System.out.println((10.5 + 2 * 3) / (45 - 3.5));
  }
}
