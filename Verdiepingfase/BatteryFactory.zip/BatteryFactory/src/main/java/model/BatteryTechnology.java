package model;

public enum BatteryTechnology {
    LEAD,LIION,NIMH,ALKALINE;
}
