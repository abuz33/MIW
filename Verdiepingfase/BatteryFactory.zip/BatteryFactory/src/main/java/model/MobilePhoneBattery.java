package model;

public class MobilePhoneBattery implements IBattery {
    private int capacityInmAh;
    private double voltageInVolt;
    private BatteryTechnology batteryTechnology;

    public MobilePhoneBattery(int capacityInmAh, double voltageInVolt) {
        this.capacityInmAh = capacityInmAh;
        this.voltageInVolt = voltageInVolt;
    }


    @Override
    public double getCapacityInmAh() {
        return 0;
    }

    @Override
    public double getVoltageInVolt() {
        return 0;
    }

    @Override
    public BatteryTechnology getBatteryTechnology() {
        return null;
    }
}
