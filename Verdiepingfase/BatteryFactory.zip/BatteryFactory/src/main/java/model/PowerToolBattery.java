package model;

public class PowerToolBattery implements IBattery {
    private int voltage;
    private int capacityInAh;
    private BatteryTechnology batteryTechnology;

    @Override
    public double getCapacityInmAh() {
        return 0;
    }

    @Override
    public double getVoltageInVolt() {
        return 0;
    }

    @Override
    public BatteryTechnology getBatteryTechnology() {
        return null;
    }
}
