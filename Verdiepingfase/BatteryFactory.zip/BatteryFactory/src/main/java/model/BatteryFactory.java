package model;

public class BatteryFactory {


    /* create a battery factory method, which has the following inputs:
    capacity
    voltage
    when capacity is > 10Ah, it is considered a lead car battery
    when capacity is <= 10Ah and voltage is > 5 V , it's a NiMh powertool battery
    when capacity is <= 10Ah and voltage is <= 5 V , it's a Li-ion mobile phone battery

    */

}
