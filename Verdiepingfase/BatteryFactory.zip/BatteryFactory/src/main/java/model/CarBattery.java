package model;

public class CarBattery implements IBattery  {
    private double capacityInAh;
    private double voltage;
    private BatteryTechnology batteryTechnology;

    public CarBattery(double capacityInAh, double voltage, BatteryTechnology batteryTechnology) {
        this.capacityInAh = capacityInAh;
        this.voltage = voltage;
        this.batteryTechnology = batteryTechnology;
    }

    @Override
    public double getCapacityInmAh() {
        return 0;
    }

    @Override
    public double getVoltageInVolt() {
        return 0;
    }

    @Override
    public BatteryTechnology getBatteryTechnology() {
        return null;
    }
}
