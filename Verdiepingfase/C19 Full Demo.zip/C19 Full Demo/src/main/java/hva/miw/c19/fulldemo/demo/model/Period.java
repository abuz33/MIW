// Created by huub
// Creation date 2020-05-19

package hva.miw.c19.fulldemo.demo.model;

import java.time.LocalDate;

public class Period {

  private String description;
  private Event start;
  private Event end;

  public Period() {
    super();
  }
}
