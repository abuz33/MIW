import os
import sys
from flask import Flask
from flask_restful import Resource, Api
from flask import make_response, jsonify

app = Flask(__name__)
api = Api(app)

userPosts = {
    1: [
        {
            "titel": "pariatur",
            "body": "Duis Lorem minim deserunt occaecat occaecat nostrud amet aute qui Lorem minim. Mollit velit eu nulla est commodo ullamco cupidatat laboris mollit minim pariatur deserunt. Ut pariatur id eu non.\r\n"
        },
        {
            "titel": "nulla",
            "body": "Est mollit irure dolore in. Cupidatat proident nostrud amet magna. Adipisicing sunt proident fugiat aliqua.\r\n"
        },
        {
            "titel": "mollit",
            "body": "Magna cupidatat eiusmod sit amet est nostrud voluptate ea occaecat labore. Sunt sunt sint elit quis consectetur consectetur cupidatat ullamco pariatur duis cillum enim occaecat. Mollit aliquip est eu veniam ipsum magna Lorem eiusmod minim et aliqua tempor fugiat ut. Ex excepteur commodo nostrud aute pariatur ipsum ullamco anim anim incididunt labore incididunt elit fugiat. Aliqua ex eiusmod commodo minim duis excepteur non ex ex do dolor. Ex tempor ipsum nulla fugiat mollit eu enim in irure cillum cillum. Occaecat magna pariatur ut elit ullamco proident exercitation in ad aliqua.\r\n"
        },
        {
            "titel": "duis",
            "body": "Aute irure elit tempor qui sint nulla culpa non. Adipisicing cillum ut veniam id Lorem duis reprehenderit reprehenderit non. Excepteur elit deserunt sit elit qui elit eu in. Id voluptate nisi proident id mollit et reprehenderit. Ut qui sint velit minim dolore labore cupidatat laboris. Cillum enim veniam dolore ea ullamco minim ex duis esse veniam. Consequat velit quis anim ipsum labore duis pariatur ad commodo magna non.\r\n"
        },
        {
            "titel": "ex",
            "body": "Cupidatat sit officia aliquip velit nulla exercitation consectetur qui nulla. Anim anim tempor adipisicing duis dolor magna. Minim sunt veniam ex amet duis laboris sunt do do. Velit exercitation excepteur aliqua eu cupidatat cupidatat officia elit culpa in enim. Mollit nulla consequat cillum esse anim occaecat ex aute ut et eu sit ullamco minim.\r\n"
        },
        {
            "titel": "velit",
            "body": "Pariatur reprehenderit anim incididunt ut ipsum ea voluptate labore ad occaecat. Nostrud consequat velit ipsum elit elit ea voluptate. Dolor nisi magna commodo pariatur sit commodo consectetur cupidatat. Enim do in sit eu aliquip Lorem reprehenderit voluptate. Sit voluptate ea enim incididunt.\r\n"
        },
        {
            "titel": "cupidatat",
            "body": "Lorem amet anim nulla id culpa. Amet occaecat labore anim velit qui ad ullamco magna nisi adipisicing aliqua non ad dolore. Consequat quis magna esse irure nostrud ipsum tempor irure aute aliquip quis pariatur. Deserunt cillum veniam velit ullamco id aliquip ut sit cillum eiusmod ea. Consequat dolor ipsum in laboris commodo ipsum magna minim proident nostrud commodo sint tempor. Ipsum dolor voluptate proident sunt nulla.\r\n"
        }
    ],
    2: [
        {
            "titel": "ut",
            "body": "Enim ad commodo non sint do ad sit cupidatat sint enim Lorem excepteur reprehenderit. Duis sunt minim excepteur aute sint do reprehenderit qui duis dolor fugiat. Veniam amet incididunt aliqua aliqua. Pariatur labore aute ex ex et mollit eiusmod minim. Est ullamco velit ullamco ullamco anim amet culpa aliquip veniam nostrud ipsum exercitation. Amet Lorem fugiat aliquip proident velit minim fugiat nisi.\r\n"
        },
        {
            "titel": "et",
            "body": "Laborum id exercitation aliquip veniam id pariatur. Velit ipsum non ad velit. Ad eu labore mollit ut tempor cupidatat. Aute aliquip qui aliqua ut voluptate. Reprehenderit eu amet in fugiat aute pariatur ullamco ea velit. Ullamco duis labore qui qui sit laboris nulla aute laborum id consectetur. Lorem sunt dolor adipisicing consectetur ut nostrud dolor labore anim sit elit anim.\r\n"
        },
        {
            "titel": "voluptate",
            "body": "Exercitation cupidatat proident laboris sunt ipsum elit. Ullamco dolore sit eu cillum minim elit eu enim labore. Ut ullamco ad aliquip reprehenderit consectetur Lorem dolore consequat elit incididunt magna minim.\r\n"
        },
        {
            "titel": "enim",
            "body": "Reprehenderit dolore eiusmod est esse. Proident quis cillum culpa ut dolore id adipisicing. Tempor consectetur occaecat consequat minim deserunt minim ut eiusmod enim minim est duis incididunt exercitation. Aliquip Lorem culpa mollit ea incididunt sint do nostrud quis quis consectetur dolore aute. Minim consequat non culpa duis qui id do proident cillum eu amet.\r\n"
        }
    ],
    3: [
        {
            "titel": "eiusmod",
            "body": "Enim consectetur ex ad anim qui magna qui. Labore commodo exercitation cillum ullamco laboris sint Lorem. Dolor consectetur labore officia quis ipsum. Consequat ut officia culpa reprehenderit id ipsum. Do excepteur deserunt minim magna.\r\n"
        },
        {
            "titel": "aliqua",
            "body": "Commodo eu veniam mollit consequat. Proident esse esse sint deserunt nisi Lorem. Mollit ullamco qui veniam sint.\r\n"
        },
        {
            "titel": "duis",
            "body": "Occaecat non eiusmod voluptate esse minim irure commodo et qui Lorem. Commodo officia Lorem labore cillum ad non ullamco nisi magna ex. Ea aliqua qui deserunt velit aliquip anim cillum et sint id adipisicing tempor nostrud. Nostrud proident sint sunt elit laboris. Nostrud in minim Lorem quis ipsum. Est adipisicing nostrud commodo nisi laboris nulla mollit voluptate qui officia veniam.\r\n"
        },
        {
            "titel": "occaecat",
            "body": "Consequat anim occaecat laboris ullamco duis ullamco. Consectetur cupidatat nostrud in et excepteur irure tempor dolor et veniam amet nostrud pariatur excepteur. Elit velit in voluptate ullamco enim fugiat occaecat sit amet incididunt incididunt et consequat. In laboris officia officia velit sit do qui adipisicing aute excepteur occaecat sit.\r\n"
        }
    ]
}


class Post(Resource):
    def get(self, user_id: int):
        posts = userPosts.get(user_id)

        if posts is None:
            print("kkakka", file=sys.stdout)
            return make_response(jsonify({ "error" : "no posts found"}), 404)
        else:
            return posts


api.add_resource(Post, '/posts/<int:user_id>')

if __name__ == '__main__':
    app.run(debug=True)